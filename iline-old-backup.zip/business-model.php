<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta charset="windows-1252">

<title>
	Website Content Writing Bangalore, Web Designing Bangalore, Technical writing, Marketing Collaterals, Abstract & Press Releases, Corporate Training, Tools Training, Book Publishing, Content Writers in Bangalore
</title>
<meta content="iline Structured Communications is an organization dedicated to handle communication issues with people in mind. iline believes that at the end of the day, only people matter and organizations are nothing but collection of people thoughts. iline Structured Communication is conceived by people (Well, you got it, it had to be people.) with over 20 years experience in active publishing field that includes book publishing, journal publishing, content writing, web designing, technical writing, popular journalism, movies and theatre. We specialize in imparting the underlying knowledge of an organization in a concise and clear language" name="description" /><meta content="Website Content Writing, Web designing, Marketing Collaterals, Abstract &amp; Press Releases, Technical writing, Corporate Training, Tools Training, Book Publishing, Content Writers in Bangalore" name="keywords" /><link href="common/iline.css" rel="stylesheet" type="text/css" />
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="jqueryslidemenu.css" />

<!--[if lte IE 7]>
<style type="text/css">
html .jqueryslidemenu{height: 1%;} /*Holly Hack for IE7 and below*/
</style>
<![endif]-->

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js"></script>
<script type="text/javascript" src="jqueryslidemenu.js"></script>
<style type="text/css">
<!--
.style1 {font-weight: bold}
-->
</style>
<script language="JavaScript">
<!--
function calcHeight()
{
  //find the height of the internal page
  var the_height=document.getElementById('pframe').contentWindow.document.body.scrollHeight;
  //change the height of the iframe
  document.getElementById('pframe').height=the_height;
}
//-->
</script>
<style type="text/css">

#dhtmltooltip{
position: absolute;
left: -300px;
width: 150px;
border: 1px solid black;
font-family:Arial, Helvetica, sans-serif;
font-size:12px;
color:#000000;
padding: 2px;
background-color: lightyellow;
visibility: hidden;
z-index: 100;
/*Remove below line to remove shadow. Below line should always appear last within this CSS*/
filter: progid:DXImageTransform.Microsoft.Shadow(color=gray,direction=135);
}

#dhtmlpointer{
position:absolute;
left: -300px;
z-index: 101;
visibility: hidden;
}


</style>
<script type="text/javascript">
function wnopen11()
{
window.open('map.html','wnpp',"menubar=0,resizable=0,width=660,height=425,top=0,scrollbars=no");
}
</script>
</head>

<body style="margin:0% 0% 0" bgcolor="#cccccc">
<script type="text/javascript">

/***********************************************
* Cool DHTML tooltip script II- � Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

var offsetfromcursorX=12 //Customize x offset of tooltip
var offsetfromcursorY=10 //Customize y offset of tooltip

var offsetdivfrompointerX=10 //Customize x offset of tooltip DIV relative to pointer image
var offsetdivfrompointerY=14 //Customize y offset of tooltip DIV relative to pointer image. Tip: Set it to (height_of_pointer_image-1).

document.write('<div id="dhtmltooltip"></div>') //write out tooltip DIV
document.write('<img id="dhtmlpointer" src="arrow2.gif">') //write out pointer image

var ie=document.all
var ns6=document.getElementById && !document.all
var enabletip=false
if (ie||ns6)
var tipobj=document.all? document.all["dhtmltooltip"] : document.getElementById? document.getElementById("dhtmltooltip") : ""

var pointerobj=document.all? document.all["dhtmlpointer"] : document.getElementById? document.getElementById("dhtmlpointer") : ""

function ietruebody(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function ddrivetip(thetext, thewidth, thecolor){
if (ns6||ie){
if (typeof thewidth!="undefined") tipobj.style.width=thewidth+"px"
if (typeof thecolor!="undefined" && thecolor!="") tipobj.style.backgroundColor=thecolor
tipobj.innerHTML=thetext
enabletip=true
return false
}
}

function positiontip(e){
if (enabletip){
var nondefaultpos=false
var curX=(ns6)?e.pageX : event.clientX+ietruebody().scrollLeft;
var curY=(ns6)?e.pageY : event.clientY+ietruebody().scrollTop;
//Find out how close the mouse is to the corner of the window
var winwidth=ie&&!window.opera? ietruebody().clientWidth : window.innerWidth-20
var winheight=ie&&!window.opera? ietruebody().clientHeight : window.innerHeight-20

var rightedge=ie&&!window.opera? winwidth-event.clientX-offsetfromcursorX : winwidth-e.clientX-offsetfromcursorX
var bottomedge=ie&&!window.opera? winheight-event.clientY-offsetfromcursorY : winheight-e.clientY-offsetfromcursorY

var leftedge=(offsetfromcursorX<0)? offsetfromcursorX*(-1) : -1000

//if the horizontal distance isn't enough to accomodate the width of the context menu
if (rightedge<tipobj.offsetWidth){
//move the horizontal position of the menu to the left by it's width
tipobj.style.left=curX-tipobj.offsetWidth+"px"
nondefaultpos=true
}
else if (curX<leftedge)
tipobj.style.left="5px"
else{
//position the horizontal position of the menu where the mouse is positioned
tipobj.style.left=curX+offsetfromcursorX-offsetdivfrompointerX+"px"
pointerobj.style.left=curX+offsetfromcursorX+"px"
}

//same concept with the vertical position
if (bottomedge<tipobj.offsetHeight){
tipobj.style.top=curY-tipobj.offsetHeight-offsetfromcursorY+"px"
nondefaultpos=true
}
else{
tipobj.style.top=curY+offsetfromcursorY+offsetdivfrompointerY+"px"
pointerobj.style.top=curY+offsetfromcursorY+"px"
}
tipobj.style.visibility="visible"
if (!nondefaultpos)
pointerobj.style.visibility="visible"
else
pointerobj.style.visibility="hidden"
}
}

function hideddrivetip(){
if (ns6||ie){
enabletip=false
tipobj.style.visibility="hidden"
pointerobj.style.visibility="hidden"
tipobj.style.left="-1000px"
tipobj.style.backgroundColor=''
tipobj.style.width=''
}
}

document.onmousemove=positiontip

</script>
<table width="980" align="center" bgcolor="#ffffff" border="0" cellspacing="0" cellpadding="0">
<tr><form action="search.html" id="cse-search-box">

    <td height="28" align="right" bgcolor="#1370AB">

    <input type="hidden" name="cx" value="003782028014774012365:1hwq1vxcdaa" />
    <input type="hidden" name="cof" value="FORID:10" />
    <input type="hidden" name="ie" value="UTF-8" />
    <input type="text" name="q" size="31" />
    <input type="submit" name="sa" value="Search" />

<script type="text/javascript" src="http://www.google.com/cse/brand?form=cse-search-box&lang=en"></script>
</td></form>

  </tr>
  <tr>
    <td height="104" bgcolor="#ECECEC"><table width="100%" height="104" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="69%" valign="middle"><img src="images/logo.jpg" width="679" height="80" /></td>
        <td width="31%" align="center" valign="middle"><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0','width','275','height','75','src','images/iline','quality','high','pluginspage','http://www.macromedia.com/go/getflashplayer','movie','images/iline' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="275" height="75">
          <param name="movie" value="images/iline.swf" />
          <param name="quality" value="high" />
          <embed src="images/iline.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="275" height="75"></embed>
        </object></noscript></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="26" bgcolor="#ECECEC"><table width="100%" height="26" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td bgcolor="#ECECEC"><table width="963" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="27"><div id="myslidemenu" class="jqueryslidemenu">
                <ul>
                  <li><a href="index.html"><img src="images/home.jpg" width="107" height="26" border="0" /></a></li>
                  <li><a href="#"><img src="images/aboutus.jpg" width="107" height="26" border="0" /></a>
                      <ul>
                        <li><a href="aboutus.php?page=profile">Profile</a></li>
                        <li><a href="aboutus.php?page=management">Management</a></li>
                        <li><a href="aboutus.php?page=capability">Capability</a></li>
                      </ul>
                  </li>
                  <li><a href="#"><img src="images/services.jpg" width="107" height="26" border="0" /></a>
                      <ul>
                        <li><a href="#">Content Development</a>
                            <ul>
                              <li><a href="services.php?page=technical-writing">Technical Writing</a></li>
                              <li><a href="services.php?page=mc">Marketing Communcations</a></li>
                              <li><a href="services.php?page=web-content">Website Content</a></li>
                              <li><a href="services.php?page=training-manual">Training Manuals</a></li>
                              <li><a href="services.php?page=abstract-writing">Abstract Writing</a></li>
                              <li><a href="services.php?page=article-press-release">Article &amp; Press releases</a></li>
                            </ul>
                        </li>
                        <li><a href="services.php?page=document-conversion">Digital Marketing</a></li>
                        <li><a href="services.php?page=editorial">Editorial Services</a></li>
                        <li><a href="services.php?page=website-development">Website Development</a></li>
                      </ul>
                  </li>
                  <li><a href="#"><img src="images/businessmodel.jpg" width="107" height="26" border="0"/></a>
                      <ul>
                        <li><a href="business-model.php?page=time-material">Time and Material</a></li>
                        <li><a href="business-model.php?page=fixed-bid-cost">Fixed Bid</a></li>
                      </ul>
                  </li>
                  <li><a href="#"><img src="images/training.jpg" width="107" height="26" border="0"/></a>
                      <ul>
                        <li><a href="training.php?page=technical-writing1">Technical Writing Training</a></li>
                        <li><a href="training.php?page=communication-skill">Communication Skills Training</a></li>
                        <li><a href="training.php?page=soft-skill">Soft Skills Training</a></li>
                        <li><a href="training.php?page=stress-management">Stress Management Training</a></li>
                        <li><a href="training.php?page=tools-training">Tools Training</a></li>
                      </ul>
                  </li>
                  <li><a href="syndicate.html"><img src="images/syndicate.jpg" width="107" height="26" border="0" /></a></li>
                  <li><a href="clients.html"><img src="images/clients.jpg" width="107" height="26" border="0" /></a></li>
                  <li><a href="careers.html"><img src="images/careers.jpg" width="107" height="26" border="0" /></a></li>
                  <li><a href="contactus.html"><img src="images/contactus.jpg" width="107" height="26" border="0" /></a></li>
                </ul>
            </div></td>
          </tr>
        </table></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td align="left" bgcolor="#5CC5F5"><img src="images/header.jpg" width="979" height="147" /></td>
  </tr>
  <tr>
    <td height="35" align="left" bgcolor="#1370AB"><img src="images/biline.jpg" width="579" height="31" /></td>
  </tr>
  <tr>
    <td height="387" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="294" height="387" valign="top" background="images/divider-left.jpg" style="background-repeat:repeat-y"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="123" align="center" valign="top"><br />
                <table width="251" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
			       <tr>
                  <td width="34" align="left" valign="middle" bgcolor="#000000"><img src="images/menubull.jpg" width="34" height="26" /></td>
                  <td width="200" align="left" valign="middle" bgcolor="#000000"><span class="style1"><a href="time-material.html" class="menu" target="pframe">Time and Material</a></span></td>
                  <td width="17" align="right" valign="middle" bgcolor="#000000"><img src="images/menuright.jpg" width="17" height="26" /></td>
                </tr>
                
                <tr>
                  <td height="12" align="left" valign="middle" bgcolor="#FFFFFF"></td>
                  <td bgcolor="#FFFFFF"></td>
                  <td align="right" valign="middle" bgcolor="#FFFFFF"></td>
                </tr>
				
				
				
                <tr>
                  <td align="left" valign="middle" bgcolor="#000000"><img src="images/menubull.jpg" width="34" height="26" /></td>
                  <td align="left" valign="middle" bgcolor="#000000"><a href="fixed-bid-cost.html" class="menu" target="pframe">Fixed Bid</a></td>
                  <td align="right" valign="middle" bgcolor="#000000"><img src="images/menuright.jpg" width="17" height="26" /></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td height="4"></td>
          </tr>
          <tr>
            <td><table width="236" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td width="236"><img src="images/connect.jpg" width="228" height="49" /></td>
              </tr>
              <tr>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="12%" style="border-bottom:1px solid #C8C8C8"><a href="javascript:wnopen11();"><img src="images/map.jpg" width="30" height="31" border="0" /></a></td>
                      <td width="88%" valign="middle" style="border-bottom:1px solid #C8C8C8"><span class="style2"><a href="javascript:wnopen11();" class="graylink1">Locate Us</a> </span></td>
                    </tr>
                    <tr>
                      <td align="center" style="border-bottom:1px solid #C8C8C8"><img src="images/phone.jpg" width="25" height="29" /></td>
                      <td valign="middle" class="graylink" style="border-bottom:1px solid #C8C8C8">080 233 2824 , +91-988 673 2823<br />
                        <span class="graylink" style="border-bottom:1px solid #C8C8C8"></td>
                    </tr>
                    <tr>
                      <td align="center" style="border-bottom:1px solid #C8C8C8"><a href="contact-content.html" target="pframe"><img src="images/home-icon.jpg" width="25" height="29" border="0" /></a></td>
                      <td valign="middle" class="graylink1" style="border-bottom:1px solid #C8C8C8"><a href="contact-content.html" class="graylink1" target="pframe" onmouseover="ddrivetip('&lt;b&gt;iline Structured Communications&lt;/b&gt;, &lt;br&gt;13, 4th Main Road, Ganganagar Extension, &lt;br&gt;Bangalore-560032, INDIA ', 250)";
onmouseout="hideddrivetip()">Visit our office</a></td>
                    </tr>
                    <tr>
                      <td align="center" style="border-bottom:1px solid #C8C8C8"><img src="images/email.jpg" width="24" height="28" /></td>
                      <td valign="middle" class="graylink1" style="border-bottom:1px solid #C8C8C8"><a href="mailto:info@iline.in" class="graylink1">Email Us</a></td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
        </table></td>
<?php 
$page=$_GET['page'];
$lnk=$page.".html";
if(!$page)
$lnk="time-material.html";
 ?>
        <td valign="top" align="center"><iframe width="656" onLoad="calcHeight();" id="pframe" name="pframe" src="<?php echo $lnk; ?>" scrolling="no" frameborder="0"></iframe></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="24" align="center" valign="middle" bgcolor="#31A5D8" class="whitetext"><a href="contactus.html" class="whitetextlink">ENQUIRY</a> | <a href="sitemap.html" class="whitetextlink">SITE MAP</a> |  <a href="#" class="whitetextlink">PRIVACY</a>  |<a href="#" class="whitetextlink">  TERMS</a></td>
  </tr>
  <tr>
    <td height="20" align="center" valign="middle" bgcolor="#000000" class="whitetext">Copyright &copy; 2020 www.iline.in - iline Structured Communications. All Rights Reserved.</td>
  </tr>
</table>

 <!-- Start of StatCounter Code -->
<script type="text/javascript">
var sc_project=5437966; 
var sc_invisible=1; 
var sc_partition=31; 
var sc_click_stat=1; 
var sc_security="7c98d2a9"; 
</script>

<script type="text/javascript"
src="http://www.statcounter.com/counter/counter.js"></script><noscript><div
class="statcounter"><a title="hit counter"
href="http://www.statcounter.com/free_hit_counter.html"
target="_blank"><img class="statcounter"
src="http://c.statcounter.com/5437966/0/7c98d2a9/1/"
alt="hit counter" ></a></div></noscript>
<!-- End of StatCounter Code -->
</body>
</html>
