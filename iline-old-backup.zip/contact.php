<?php
ini_set ("SMTP","localhost");
ini_set ("sendmail_from","info@iline.in");
if(isset($_POST['Submitregister']))
{
	$name = $_POST['txtname'];
	$address = $_POST['txtaddress'];
	$phone = $_POST['txtnum'];
	$email = $_POST['txtemail'];
	$edu = $_POST['edu'];
	$txtexp = $_POST['txtexp'];
	$applied = $_POST['applied'];
	$project = $_POST['txtproject'];
	$resume = $_POST['txtresume'];
	// inform admin
	$emaila="ayesha@iline.in";
	$mail_sub="iline Career - Register With Us";
	$mail_header="<table width='756' border='0'><tr><td height='30' colspan='2'>
												<a href='http://www.iline.in'><img src='http://www.iline.in/images/logo.jpg' border='0' /></a></td>
												</tr><tr><td>";
	$mail_body="<br><br>
	Dear <b> Admin</b><br>";
	$mail_body=$mail_body."You have received a Career Enquiry.<br>
	Name -  $name <br>Address -  $address <br>Contact Number -  $phone <br> Email - $email <br> Education - $edu <br>Experience -  $txtexp <br>Post applied for -  $applied <br> Project done - $project <br>Brief Resume -  $resume <br>
	
                  <br /> <br><br>";
	$mail_body=$mail_body."Thanks & Regards<br><br />
	<br>";
	$mail_footer="</td></tr></table>";
	$email_message=$mail_header.$mail_body.$mail_footer;
//	echo $mail_mesg."<br>";
	$mail_from='"'.$name.'"<'.$email.'>';
	// Obtain file upload vars
	$fileatt      = $_FILES['fileattach']['tmp_name'];
	$fileatt_type = $_FILES['fileattach']['type'];
	$fileatt_name = $_FILES['fileattach']['name'];
	$headers = 'From:'.$mail_from;
//	if (is_uploaded_file($fileatt)) {
	 // Read the file to be attached ('rb' = read binary)
	 $file = fopen($fileatt,'rb');
	 $data = fread($file,filesize($fileatt));
	 fclose($file);
	 // Generate a boundary string
	 $semi_rand = md5(time());
	 $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
	 
	 // Add the headers for a file attachment
	 $headers .= "\nMIME-Version: 1.0\n" .
				 "Content-Type: multipart/mixed;\n" .
				 " boundary=\"{$mime_boundary}\"";
				 // Add a multipart boundary above the plain message
	 $message = "This is a multi-part message in MIME format.\n\n" .
				"--{$mime_boundary}\n" .
				"Content-Type: text/html; charset=\"iso-8859-1\"\n" .
				"Content-Transfer-Encoding: 7bit\n\n" .
				$email_message . "\n\n";
				// Base64 encode the file data
	 $data = chunk_split(base64_encode($data));
	 // Add file attachment to the message
	 $message .= "--{$mime_boundary}\n" .
				 "Content-Type: {$fileatt_type};\n" .
				 " name=\"{$fileatt_name}\"\n" .
				 "Content-Disposition: attachment;\n" .
				 " filename=\"{$fileatt_name}\"\n" .
				 "Content-Transfer-Encoding: base64\n\n" .
				 $data . "\n\n" .
				 "--{$mime_boundary}--\n";
//	}
	mail($emaila,$mail_sub,$message,$headers);
	header("Location: contact-thanks.html");
}
?>
<?php
if(isset($_POST['Submitcontact']))
{
	$name = $_POST['txtname'];
	$enquiry = $_POST['enquiry'];
	$company = $_POST['company'];
	$email = $_POST['txtemail'];
	$msg = $_POST['message'];


// inform admin
$emaila="ayesha@iline.in";
$mail_sub="iline - Contact Us";
$mail_header="<table width='756' border='0'><tr><td height='30' colspan='2'>
											<a href='http://www.iline.in'><img src='http://www.iline.in/images/logo.jpg' border='0' /></a></td>
											</tr><tr><td>";
	$mail_body="<br><br>
	Dear <b> Admin</b><br>";
	$mail_body=$mail_body."You have received a contact us request.<br>
	Name -  $name <br>Enquiry -  $enquiry <br>Coompany -  $company <br> Email - $email <br> Message - $msg <br>
	
                  <br /> <br><br>";
	$mail_body=$mail_body."Thanks & Regards<br><br />
	<br>";
	$mail_footer="</td></tr></table>";
	$email_message=$mail_header.$mail_body.$mail_footer;
//	echo $mail_mesg."<br>";
	$mail_from='"'.$name.'"<'.$email.'>';
	// Obtain file upload vars
	$fileatt      = $_FILES['fileattach']['tmp_name'];
	$fileatt_type = $_FILES['fileattach']['type'];
	$fileatt_name = $_FILES['fileattach']['name'];
	$headers = 'From:'.$mail_from;
//	if (is_uploaded_file($fileatt)) {
	 // Read the file to be attached ('rb' = read binary)
	 $file = fopen($fileatt,'rb');
	 $data = fread($file,filesize($fileatt));
	 fclose($file);
	 // Generate a boundary string
	 $semi_rand = md5(time());
	 $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
	 
	 // Add the headers for a file attachment
	 $headers .= "\nMIME-Version: 1.0\n" .
				 "Content-Type: multipart/mixed;\n" .
				 " boundary=\"{$mime_boundary}\"";
				 // Add a multipart boundary above the plain message
	 $message = "This is a multi-part message in MIME format.\n\n" .
				"--{$mime_boundary}\n" .
				"Content-Type: text/html; charset=\"iso-8859-1\"\n" .
				"Content-Transfer-Encoding: 7bit\n\n" .
				$email_message . "\n\n";
				// Base64 encode the file data
	 $data = chunk_split(base64_encode($data));
	 // Add file attachment to the message
	 $message .= "--{$mime_boundary}\n" .
				 "Content-Type: {$fileatt_type};\n" .
				 " name=\"{$fileatt_name}\"\n" .
				 "Content-Disposition: attachment;\n" .
				 " filename=\"{$fileatt_name}\"\n" .
				 "Content-Transfer-Encoding: base64\n\n" .
				 $data . "\n\n" .
				 "--{$mime_boundary}--\n";
//	}
	mail($emaila,$mail_sub,$message,$headers);
	header("Location: contact-thanks.html");
}
?>
<?
if(isset($_POST['Submitsyndicate']))
{
	$fname = $_POST['first_name'];
	$lname = $_POST['last_name'];
	$company = $_POST['company'];
	$title = $_POST['txttitle'];
	$city = $_POST['city'];
	$state = $_POST['state'];
	$country = $_POST['country'];
	$zip = $_POST['zip'];
	$phone = $_POST['phone'];
	$email = $_POST['txtemail'];
	$msg = $_POST['message'];


// inform admin
$emaila="ayesha@iline.in";
$mail_sub="iline Syndicate - Enquiry";
$mail_header="<table width='756' border='0'><tr><td height='30' colspan='2'>
											<a href='http://www.iline.in'><img src='http://www.iline.in/images/logo.jpg' border='0' /></a></td>
											</tr><tr><td>";
	$mail_body="<br><br>
	Dear <b> Admin</b><br>";
	$mail_body=$mail_body."You have received a syndicate request.<br>
	First name -  $fname <br>Last name -  $lname <br>Company name - $company <br>Position/title -  $title <br>City -  $city <br>State - $state <br>Country -  $country <br>Contact number -  $phone <br> Email - $email <br>Other relevant information or questions -  $msg <br>
	
                  <br /> <br><br>";
	$mail_body=$mail_body."Thanks & Regards<br><br />
	<br>";
	$mail_footer="</td></tr></table>";
	$email_message=$mail_header.$mail_body.$mail_footer;
//	echo $mail_mesg."<br>";
	$mail_from='"'.$name.'"<'.$email.'>';
	// Obtain file upload vars
	$headers = 'From:'.$mail_from;
//	if (is_uploaded_file($fileatt)) {
	 // Read the file to be attached ('rb' = read binary)
	 $file = fopen($fileatt,'rb');
	 $data = fread($file,filesize($fileatt));
	 fclose($file);
	 // Generate a boundary string
	 $semi_rand = md5(time());
	 $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
	 
	 // Add the headers for a file attachment
	 $headers .= "\nMIME-Version: 1.0\n" .
				 "Content-Type: multipart/mixed;\n" .
				 " boundary=\"{$mime_boundary}\"";
				 // Add a multipart boundary above the plain message
	 $message = "This is a multi-part message in MIME format.\n\n" .
				"--{$mime_boundary}\n" .
				"Content-Type: text/html; charset=\"iso-8859-1\"\n" .
				"Content-Transfer-Encoding: 7bit\n\n" .
				$email_message . "\n\n";
				// Base64 encode the file data
	 $data = chunk_split(base64_encode($data));
	 // Add file attachment to the message
	 
				
	mail($emaila,$mail_sub,$message,$headers);
	header("Location: contact-thanks.html");
}
?>
